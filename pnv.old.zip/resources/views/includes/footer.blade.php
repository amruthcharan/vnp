<footer class="footer text-center">
    All Rights Reserved by Vet N Pet. Designed and Developed by Aresol</a>.
</footer>