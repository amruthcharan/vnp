<!-- Custom CSS -->
<link href="<?php echo e(asset('assets/libs/fullcalendar/dist/fullcalendar.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/extra-libs/calendar/calendar.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('dist/css/style.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/libs/select2/dist/css/select2.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('assets/libs/toastr/build/toastr.min.css')); ?>" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/libs/bootstrap-datepicker/dist/css/bootstrap-datepicker3.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/libs/print/print.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/jquery-ui.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/st.css')); ?>">