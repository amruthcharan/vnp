<?php $__env->startSection('title'); ?>
    <title>Vet N Pet - Diagnoses</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrum'); ?>
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h4 class="page-title">Diagnoses</h4>
                <div class="ml-auto text-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Diagnoses</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <h4 class="float-left">Diagnoses List</h4>
                        <div class="float-right">
                            <?php echo Form::open(['method'=>'POST', 'action' => 'DiagnosisController@store', 'class'=>'form-inline']); ?>

                            <div class="form-group">
                                <?php echo Form::label('name', 'Diagnosis:'); ?>

                                <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

                            </div>
                            <div class="card-body">
                                <?php echo Form::submit('Add', ['class'=>'btn btn-primary']); ?>

                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table id="owners" class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(isset($diagnoses)): ?>
                                <?php foreach($diagnoses as $diagnosis): ?>
                                    <tr>
                                        <td><?php echo e($diagnosis->id); ?></td>
                                        <td><?php echo e($diagnosis->name); ?></td>
                                        <td>
                                            <a class="btn btn-dribbble" href="<?php echo e(route('diagnoses.edit', $diagnosis->id)); ?>">Edit</a>
                                            <?php /*<a href="javascript:void(0)" data-toggle="modal" id="edit" data-id="<?php echo e($symptom->name); ?>" data-target="#edit-symptom" class="btn btn-info waves-effect waves-light">Edit</a>*/ ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>