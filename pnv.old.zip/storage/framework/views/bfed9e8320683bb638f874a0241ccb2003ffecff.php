<?php $__env->startSection('title'); ?>
    <title>Vet N Pet - <?php echo e($patient->name); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrum'); ?>
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h4 class="page-title"><?php echo e($patient->name); ?></h4>
                <div class="ml-auto text-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <span class="text-right"><a class="btn btn-sm btn-success" onclick="window.history.back();">back</a></span>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <!-- column -->
        <div class="col-md-6">
            <!-- Card -->
            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <h4 class="float-left">Owner Details</h4>
                        <a class='float-right' href="<?php echo e(route('patients.edit',$patient->id)); ?>"><i class="ti-pencil-alt"></i></a>
                    </div>
                    <div class="table-responsive m-t-40" style="clear: both;">
                        <table class="table table-hover">
                            <tbody>
                            <tr>
                                <td class="text-left">Owner Name</td>
                                <td>:</td>
                                <td class="text-left"><?php echo e($patient->ownername); ?></td>
                            </tr>
                            <tr>
                                <td class="text-left">Mobile Number</td>
                                <td>:</td>
                                <td class="text-left"><?php echo e($patient->mobile); ?></td>
                            </tr>
                            <tr>
                                <td class="text-left">Email Address</td>
                                <td>:</td>
                                <td class="text-left"><?php echo e($patient->email); ?></td>
                            </tr>
                            <tr>
                                <td class="text-left">Address</td>
                                <td>:</td>
                                <td class="text-left"><?php echo e($patient->address); ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Appointments Card -->
            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <h4 class="float-left">Appointments</h4>
                        <a class='float-right' href="<?php echo e(route('appointments.create','patid='.$patient->id)); ?>"><b><i class="ti-plus"></i></b></a>
                    </div>
                    <div class="table-responsive m-t-40" style="clear: both;">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Doctor Name</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <?php foreach($patient->appointments as $appointment): ?>
                                <tbody>
                                <tr>
                                    <td class="text-left"><?php echo e($appointment->id); ?></td>
                                    <td><?php echo e($appointment->doctor->name); ?></td>
                                    <td class="text-left"><?php echo e($appointment->date->format('d-m-Y')); ?></td>
                                    <td class="text-left">
                                        <?php if($appointment->prescription): ?>
                                            <a href='<?php echo e(url('/prescriptions/'.$appointment->prescription->id.'/print')); ?>' target="popup" onclick="window.open('<?php echo e(url('prescriptions/'.$appointment->prescription->id.'/print')); ?>','popup','width=1300,height=700,location=0,scrollbars=no,resizable=no'); return false;">View Prescription</a>
                                        <?php else: ?>
                                            <?php echo e($appointment->status); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                </tbody>
                            <?php endforeach; ?>
                        </table>
                    </div>
                </div>
            </div>
            <?php if(!$patient->vaccinations->isEmpty()): ?>
                <div class="card">
                    <div class="card-body">
                        <div class="card-title">
                            <h4 class="float-left">Vaccination Details</h4>
                            <a class='float-right' href="<?php echo e(route('patients.create','patid='.$patient->id)); ?>"><i class="ti-plus"></i></a>
                        </div>
                        <div class="table-responsive m-t-40" style="clear: both;">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Vaccine Name</th>
                                    <th>Date</th>
                                    <th>Expiry</th>
                                    <th>Action</th>
                                </tr>
                                </thead>


                                <?php foreach($patient->vaccinations as $v): ?>
                                    <tbody>
                                    <tr style="<?php echo e($v->expiry < \Carbon\Carbon::today() ?  "color:red;font-weight: bold;" : "color:green; font-weight: bold;"); ?>">
                                        <td class="text-left"><?php echo e($v->id); ?></td>
                                        <td><?php echo e($v->vaccine->name); ?></td>
                                        <td class="text-left"><?php echo e($v->date->format('d-m-Y')); ?></td>
                                        <td class="text-left"><?php echo e($v->expiry->format('d-m-Y')); ?></td>
                                        <td class="text-left"><a href="<?php echo e(route('patients.edit',$v->id)); ?>" class="btn btn-primary btn-xs">Edit</a></td>
                                    </tr>
                                    </tbody>
                                <?php endforeach; ?>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <!-- column -->
        <div class="col-md-6">
            <!-- Card -->
            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <h4 class="float-left">Patient Details</h4>
                        <a class='float-right' href="<?php echo e(route('patients.edit',$patient->id)); ?>"><i class="ti-pencil-alt"></i></a>
                    </div>
                    <div class="table-responsive m-t-40" style="clear: both;">
                        <table class="table table-hover">
                            <tbody>
                            <tr>
                                <td class="text-left">Name</td>
                                <td>:</td>
                                <td class="text-left"><?php echo e($patient->name); ?></td>
                            </tr>
                            <tr>
                                <td class="text-left">Species</td>
                                <td>:</td>
                                <td class="text-left"><?php echo e($patient->species ? $patient->species->name : ''); ?></td>
                            </tr>
                            <tr>
                                <td class="text-left">Gender</td>
                                <td>:</td>
                                <td class="text-left"><?php echo e($patient->gender); ?></td>
                            </tr>
                            <tr>
                                <td class="text-left">Age</td>
                                <td>:</td>
                                <td class="text-left"><?php echo e($patient->age ? $patient->age->format('d-m-Y') : ''); ?></td>
                            </tr>
                            <tr>
                                <td class="text-left">Breed</td>
                                <td>:</td>
                                <td class="text-left"><?php echo e($patient->breed); ?></td>
                            </tr>
                            <tr>
                                <td class="text-left">Feeding Pattern</td>
                                <td>:</td>
                                <td class="text-left"><?php echo e($patient->feeding_pattern); ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Card -->
            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <h4 class="float-left">Invoices</h4>
                        <a class='float-right' href="<?php echo e(route('bills.create','patid='.$patient->id)); ?>"><b><i class="ti-plus"></i></b></a>
                    </div>
                    <div class="table-responsive m-t-40" style="clear: both;">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Date</th>
                                <th>Net Amount</th>
                                <th>Discount</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <?php foreach($patient->bills as $bill): ?>
                                <tbody>
                                <tr>
                                    <td class="text-left"><?php echo e($bill->id); ?></td>
                                    <td><?php echo e($bill->date->format('d-m-Y')); ?></td>
                                    <td class="text-left"><?php echo e($bill->nettotal); ?></td>
                                    <td class="text-left"><?php echo e($bill->discount); ?></td>
                                    <td class="text-left"><a href="<?php echo e(url('/bills/'.$bill->id.'/print')); ?>" target="popup" onclick="window.open('<?php echo e(url('bills/'.$bill->id.'/print')); ?>','popup','width=1300,height=700,location=0,scrollbars=no,resizable=no'); return false;">View Invoice</a></td>
                                </tr>
                                </tbody>
                            <?php endforeach; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).on('click','#help', function () {
            var hello = $('.datelp').val();
            console.log(hello);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>