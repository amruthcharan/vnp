<?php $__env->startSection('title'); ?>
    <title>Vet N Pet - Users</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrum'); ?>
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h4 class="page-title">Owners</h4>
                <div class="ml-auto text-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Owners</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <h4 class="float-left">Owners List</h4>
                        <a class='btn btn-primary btn-sm float-right' href="<?php echo e(route('owners.create')); ?>"><i class="ti-plus"></i><strong> New</strong></a>
                    </div>

                    <div class="table-responsive">
                        <table id="owners" class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Email</th>
                                <th>Mobile Number</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(isset($owners)): ?>
                                <?php foreach($owners as $owner): ?>
                                    <tr>
                                        <td><?php echo e($owner->name); ?></td>
                                        <td><?php echo e($owner->Address); ?></td>
                                        <td><?php echo e($owner->email); ?></td>
                                        <td><?php echo e($owner->mobile); ?></td>
                                        <td>
                                            <a class="btn btn-dribbble" href="<?php echo e(route('owners.edit', $owner->id)); ?>">Edit</a>
                                            <?php /*<a href="javascript:void(0)" data-toggle="modal" data-target="#delete-user" class="btn btn-info waves-effect waves-light">Delete</a>*/ ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $('#owners').DataTable();

        <?php if(Session::has('message')): ?>
        var type = "<?php echo e(Session::get('alert-type')); ?>";

        switch(type){
            case 'info':
                toastr.info("<?php echo e(session('message')); ?>", "<?php echo e(session('head')); ?>");
                break;
            case 'success':
                toastr.success("<?php echo e(session('message')); ?>", "<?php echo e(session('head')); ?>");
                break;
            case 'danger':
                toastr.error("<?php echo e(session('message')); ?>", "<?php echo e(session('head')); ?>");
                break;
            case 'warning':
                toastr.warning("<?php echo e(session('message')); ?>", "<?php echo e(session('head')); ?>");
                break;
        }
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>