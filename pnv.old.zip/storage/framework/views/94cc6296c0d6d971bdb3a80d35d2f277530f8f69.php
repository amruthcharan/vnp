<?php $__env->startSection('title'); ?>
    <title>Vet N Pet - Invoice</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrum'); ?>
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h4 class="page-title">View Invoice</h4>
                <div class="ml-auto text-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Invoice</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row" id="printid">
        <div class="col-md-12">
            <div class="card card-body printableArea">
                <h3><b>Invoice #</b> <span class="pull-right"><?php echo e($bill->id); ?></span></h3>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                        <div class="float-left">
                            <address>
                                <img src="<?php echo e(asset('assets/images/vnplogo.jpg')); ?>" width="120px">
                                <p class="m-l-5" style="font-size:16px;">Plot No 369/1,
                                    <br/> Phase 3, Film Nagar
                                    <br/> Jubilee Hills
                                    <br/> Hyderabad - 500096</p>
                            </address>
                        </div>
                        <div class="float-right text-right">
                            <p style="font-size:16px;"><b>Invoice Date :</b> <i class="fa fa-calendar"></i> <?php echo e($bill->created_at); ?></p>
                            <address>
                                <h4>Invoice is For,</h4>
                                <p class="m-l-30" style="font-size:16px;"><b>Name</b> - <?php echo e($bill->patient->name); ?>

                                    <br/> <?php echo e($bill->patient->address); ?>,
                                    <br/> <b>Breed</b> - <?php echo e($bill->patient->breed); ?>,
                                    <br/> <b>Invoice Prepared by <?php echo e($bill->created_by); ?></b>.
                                </p>
                            </address>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <h4 class="m-t-20">Medicines List:</h4>
                        <div class="table-responsive" style="clear: both;" style="font-size:16px;">
                            <table class="table table-hover" style="font-size:16px;">
                                <thead>
                                <tr>
                                    <th class="text-center">#</th>
                                    <th>Particulars</th>
                                    <th class="text-right">Amount</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php 
                                    $i = 1;
                                 ?>
                                <?php foreach($bill->billcomponents as $d): ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($i); ?></td>
                                        <td><?php echo e($d->name); ?></td>
                                        <td class="text-right">
                                            <?php echo e($d->amount); ?>

                                        </td>
                                    </tr>
                                    <?php 
                                        $i++
                                     ?>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-12" style="font-size:13px;">
                        <div class="pull-right m-t-30 text-right">
                            <p>Sub - Total amount: ₹ <?php echo e($bill->grandtotal); ?></p>
                            <?php 
                                if(strchr($bill->discount,"%") == ""){
                                    $ret = '₹ ' . $bill->discount;
                                } else {
                                    $ret = $bill->discount;
                                }
                             ?>
                            <p>discount : <?php echo e($ret); ?></p>
                            <hr>
                            <h3><b>Total :</b> ₹ <?php echo e($bill->nettotal); ?></h3>
                        </div>
                        <div class="clearfix"></div>
                        <hr>
                        <div class="text-center">
                            <buttton class="btn btnpr btn-info" onclick="printit()"> Print Prescription </buttton>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function printit() {
            $('.btnpr').hide();
            window.print();
            window.close();
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.print', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>