<?php $__env->startSection('title'); ?>
    <title>Vet N Pet - Packages</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrum'); ?>
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h4 class="page-title">Packages</h4>
                <div class="ml-auto text-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Packages</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <h4>Packages List</h4>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="table-responsive">
                                <table id="owners" class="table table-striped table-bordered">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Validity</th>
                                        <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(isset($packages)): ?>
                                        <?php foreach($packages as $package): ?>
                                        <tr>
                                                <td><?php echo e($package->id); ?></td>
                                                <td><?php echo e($package->name); ?></td>
                                                <td><?php echo e($package->validity); ?> Months</td>
                                                <td>
                                                    <a class="btn btn-dribbble" href="<?php echo e(route('packages.edit', $package->id)); ?>">Edit</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="col-1"></div>
                        <div class="col-5">
                            <?php echo Form::open(['method'=>'POST', 'action' => 'PackageController@store', 'class'=>'']); ?>

                            <div class="form-group">
                                <?php echo Form::label('name', 'Package Name:'); ?>

                                <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('validity', 'Validity in months:'); ?>

                                <?php echo Form::number('validity', null, ['class'=>'form-control']); ?>

                            </div>
                            <div class="card-body">
                                <?php echo Form::submit('Add New Package', ['class'=>'btn btn-primary btn-block']); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>