<?php $__env->startSection('title'); ?>
    <title>Vet N Pet - Patients</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrum'); ?>
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h4 class="page-title">Patients</h4>
                <div class="ml-auto text-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Patients</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <h4 class="float-left">Patients List</h4>
                        <a class='btn btn-primary btn-sm float-right' href="<?php echo e(route('patients.create')); ?>"><i class="ti-plus"></i><strong> New</strong></a>
                    </div>

                    <div class="table-responsive">
                        <table id="owners" class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Age</th>
                                <th>Owner Name</th>
                                <th>Species</th>
                                <th>Breed</th>
                                <th>Mobile</th>
                                <th>Gender</th>
                                <th>Feeding Pattern</th>
                                <th>Created On</th>
                                <?php foreach($vaccines as $vac): ?>
                                    <th><?php echo e($vac->name); ?></th>
                                <?php endforeach; ?>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(isset($patients)): ?>
                                <?php foreach($patients as $patient): ?>
                                    <tr>
                                        <td><?php echo e($patient->id); ?></td>
                                        <td><?php echo e($patient->name); ?></td>
                                        <td><?php echo e($patient->age ? $patient->age->format('d-m-Y') : ''); ?></td>
                                        <td><?php echo e($patient->ownername ? $patient->ownername : ""); ?></td>
                                        <td><?php echo e($patient->species ? $patient->species->name : ""); ?></td>
                                        <td><?php echo e($patient->breed ? $patient->breed : ""); ?></td>
                                        <td><?php echo e($patient->mobile ? $patient->mobile : ""); ?></td>
                                        <td><?php echo e($patient->gender ? $patient->gender : ""); ?></td>
                                        <td><?php echo e($patient->feeding_pattern ? $patient->feeding_pattern : ""); ?></td>
                                        <td><?php echo e($patient->created_at ? $patient->created_at->format('d-m-Y') : ''); ?></td>
                                        <?php foreach($vaccines as $vac): ?>
                                            <?php  $j = true;  ?>
                                            <?php for($i=0;$i < count($patient->vaccinations); $i++): ?>
                                                <?php if($patient->vaccinations[$i]->vaccine_id   == $vac->id): ?>
                                                <td>
                                                    <div style='font-weight: bold; <?php echo e($patient->vaccinations[$i]->expiry > \Carbon\Carbon::today() ? 'color:green;' : 'color:red;'); ?>'><?php echo e($patient->vaccinations[$i]->expiry->format('d-m-Y')); ?></div>
                                                </td>
                                                    <?php  $j = false  ?>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                            <?php if($j): ?>
                                                <td>Not Found</td>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                        <td>
                                            <a class="btn btn-dribbble" href="<?php echo e(route('patients.edit', $patient->id)); ?>">Edit</a>
                                            <a class="btn btn-info" href="<?php echo e(route('patients.show', $patient->id)); ?>">Patient Info</a>
                                            <button class="btn btn-warning" onclick="quickAppointment(<?php echo e($patient->id); ?>)">Quick Appointment</button>
                                            <a class="btn btn-success" href="<?php echo e('/bills/create?patid='.$patient->id); ?>">Invoice</a>
                                            <?php /*<a href="javascript:void(0)" data-toggle="modal" data-target="#delete-user" class="btn btn-info waves-effect waves-light">Delete</a>*/ ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        var Table = $('#owners').DataTable({
            "order": [0,'desc'],
        });
        yadcf.init(Table , [{
            column_number: 4,
            select_type: 'select2',
            select_type_options: {

                placeholder: '',
                allowClear: true  // show 'x' (remove) next to selection inside the select itself
            },
            column_data_type: "html",
            html_data_type: "text",
            filter_reset_button_text: false // hide yadcf reset button
        }, {
            column_number: 5,
            select_type: 'select2',
            select_type_options: {
                placeholder: '',
                allowClear: true  // show 'x' (remove) next to selection inside the select itself
            },
            column_data_type: "html",
            html_data_type: "text",
            filter_reset_button_text: false // hide yadcf reset button
        }, {
            column_number: 7,
            select_type: 'select2',
            select_type_options: {

                placeholder: '',
                allowClear: true  // show 'x' (remove) next to selection inside the select itself
            },
            column_data_type: "html",
            html_data_type: "text",
            filter_reset_button_text: false // hide yadcf reset button
        }, {
            column_number: 8,
            select_type: 'select2',
            select_type_options: {
                placeholder: '',
                allowClear: true  // show 'x' (remove) next to selection inside the select itself
            },
            column_data_type: "html",
            html_data_type: "text",
            filter_reset_button_text: false // hide yadcf reset button
        }]);

        <?php if(Session::has('message')): ?>
        var type = "<?php echo e(Session::get('alert-type')); ?>";

        switch(type){
            case 'info':
                toastr.info("<?php echo e(session('message')); ?>", "<?php echo e(session('head')); ?>");
                break;
            case 'success':
                toastr.success("<?php echo e(session('message')); ?>", "<?php echo e(session('head')); ?>");
                break;
            case 'danger':
                toastr.error("<?php echo e(session('message')); ?>", "<?php echo e(session('head')); ?>");
                break;
            case 'warning':
                toastr.warning("<?php echo e(session('message')); ?>", "<?php echo e(session('head')); ?>");
                break;
        }
        <?php endif; ?>
        function quickAppointment(pid) {
            var url = '/quickapp/' + pid;
            $(document).ajaxStart(function(){
                $(".preloader").show();
            }).ajaxStop(function(){
                $(".preloader").fadeOut();
            });
            $.ajax({
                method: 'GET',
                url: url,
                success: function (res) {
                    window.location.assign('/prescriptions/create?appid='+res.id);
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>