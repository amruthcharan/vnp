<?php $__env->startSection('title'); ?>
    <title>Vet N Pet - Users</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrum'); ?>
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h4 class="page-title">Users</h4>
                <div class="ml-auto text-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Users</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <h4 class="float-left">Users List</h4>
                        <a class='btn btn-primary btn-sm float-right' href="<?php echo e(route('users.create')); ?>"><i class="ti-plus"></i><strong> New</strong></a>
                    </div>

                    <div class="table-responsive">
                        <table id="users" class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(isset($users)): ?>
                                <?php foreach($users as $user): ?>
                                    <tr>
                                        <td><a href="<?php echo e(route('users.edit', $user->id)); ?>"><?php echo e($user->name); ?></a></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->role->name); ?></td>
                                        <td><?php echo e($user->is_active == 1 ? 'Active' : 'Not Active'); ?></td>
                                        <td>
                                            <a class="btn btn-dribbble" href="<?php echo e(route('users.edit', $user->id)); ?>">Edit</a>
                                            <a href="javascript:void(0)" data-toggle="modal" data-target="#delete-user" class="btn btn-info waves-effect waves-light">Delete</a>
                                            <?php /*<?php echo Form::open(['method'=>"DELETE", 'action'=>['UserController@destroy', $user->id]]); ?>

                                            <?php echo Form::submit('Delete', ['class'=>'btn btn-info']); ?>

                                            <?php echo Form::close(); ?>*/ ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('includes.model', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $('#users').DataTable({
            "order": [0,'desc']
        });

        <?php if(Session::has('message')): ?>
        var type = "<?php echo e(Session::get('alert-type')); ?>";

        switch(type){
            case 'info':
                toastr.info("<?php echo e(session('message')); ?>", "<?php echo e(session('head')); ?>");
                break;
            case 'success':
                toastr.success("<?php echo e(session('message')); ?>", "<?php echo e(session('head')); ?>");
                break;
            case 'danger':
                toastr.error("<?php echo e(session('message')); ?>", "<?php echo e(session('head')); ?>");
                break;
            case 'warning':
                toastr.warning("<?php echo e(session('message')); ?>", "<?php echo e(session('head')); ?>");
                break;
        }

        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>