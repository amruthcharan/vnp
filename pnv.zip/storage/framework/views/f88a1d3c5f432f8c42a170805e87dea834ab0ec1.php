<?php $__env->startSection('title'); ?>
    <title>Vet N Pet - New User</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrum'); ?>
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h4 class="page-title">Edit Owner Details</h4>
                <div class="ml-auto text-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Owners</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row" style="margin: 0 auto">
        <div class="col-md-6"  style="margin: 0 auto">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title" style="text-align: center">Edit <strong><?php echo e($owner->name); ?></strong></h4>
                    <?php echo $__env->make('includes.formerror', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo Form::open(['method'=>'PATCH', 'action' => ['OwnerController@update',$owner->id]]); ?>

                    <div class="form-group">
                        <?php echo Form::label('name', 'Name:'); ?>

                        <?php echo Form::text('name', $owner->name, ['class'=>'form-control']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('address', 'Address:'); ?>

                        <?php echo Form::text('address', $owner->Address, ['class'=>'form-control']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('mobile', 'Mobile:'); ?>

                        <?php echo Form::text('mobile', $owner->mobile, ['class'=>'form-control']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('email', 'Email:'); ?>

                        <?php echo Form::text('email', $owner->email, ['class'=>'form-control']); ?>

                    </div>
                    <div class="border-top">
                        <div class="card-body">
                            <?php echo Form::submit('Update Owner', ['class'=>'btn btn-dribbble btn-block']); ?>

                        </div>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>