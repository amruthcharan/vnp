@extends('layouts.login')

@section('content')
<h1>welcome page</h1>
@endsection
