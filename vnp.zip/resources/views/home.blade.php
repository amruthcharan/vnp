@extends('layouts.login')

@section('content')
<h1>Home Page</h1>
@endsection
