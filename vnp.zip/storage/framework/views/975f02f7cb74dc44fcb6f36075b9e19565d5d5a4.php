<?php $__env->startSection('title'); ?>
    <title>Vet N Pet - Reminders</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Reminders</h5>
                <div class="table-responsive">
                    <table id="zero_config" class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Pet Name</th>
                            <th>Owner Name</th>
                            <th>Mobile Number</th>
                            <th>Email</th>
                            <th>Reminder Date</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach($reminders as $rem): ?>
                            <?php if($rem->prescription == null): ?>
                                <tr>
                                    <td><?php echo e($rem->id); ?></td>
                                    <td><?php echo e($rem->patient->name); ?></td>
                                    <td><?php echo e($rem->patient->ownername); ?></td>
                                    <td><?php echo e($rem->patient->mobile); ?></td>
                                    <td><?php echo e($rem->patient->email ? $rem->patient->email : ""); ?></td>
                                    <td><?php echo e(date('d-m-Y', strtotime($rem->date))); ?></td>
                                    <td><button class="btn btn-danger sendsms">Send SMS</button></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('#zero_config').DataTable({"order": [5,'asc']});

        $('table').delegate('.sendsms','click', function(){
            var aid = $(this).closest('tr').find('td').eq(0).html();
            $(document).ajaxStart(function(){
                $(".preloader").show();
            }).ajaxStop(function(){
                $(".preloader").fadeOut();
            });
            $.ajax({
                url : "/sendsms/"+aid,
                success:function(d){
                    console.log(d);
                },
                error:function (e) {
                    console.log(JSON.stringify(e));
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>